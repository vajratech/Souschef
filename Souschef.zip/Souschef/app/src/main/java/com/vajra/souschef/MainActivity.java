package com.vajra.souschef;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.PopupMenu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //Home
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageButton homeButton = findViewById(R.id.homeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView stateText = findViewById(R.id.stateText);
                stateText.setText("Home");
            }
        });

        //Shopping list
        ImageButton shoppinglistButton = findViewById(R.id.shoppinglistButton);
        shoppinglistButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView stateText = findViewById(R.id.stateText);
                stateText.setText("Shopping list");
            }
        });

        //Explore
        ImageButton mapButton = findViewById(R.id.mapButton);
        mapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView stateText = findViewById(R.id.stateText);
                stateText.setText("Explore");
            }
        });

        //Community
        ImageButton communityButton = findViewById(R.id.communityButton);
        communityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView stateText = findViewById(R.id.stateText);
                stateText.setText("Community");
            }
        });

        //Courses
        ImageButton coursesButton = findViewById(R.id.coursesButton);
        coursesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView stateText = findViewById(R.id.stateText);
                stateText.setText("Courses");
            }
        });

        //Profile
        final ImageButton profileButton = findViewById(R.id.profileButton);
        profileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final PopupMenu popup = new PopupMenu(MainActivity.this, profileButton);
                popup.getMenuInflater().inflate(R.menu.profilepopup, popup.getMenu());
                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        CharSequence popupChoice = item.getTitle();
                        return true;
                    }
                });

                popup.show();//showing popup menu
            }
        });

    }
}


